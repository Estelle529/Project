<?php


namespace app\api\controller\v1;


use app\api\controller\BaseController;
use app\lib\exception\SuccessMessage;
use think\Db;
use think\Request;

class AdminNew extends BaseController
{
    public function getParams(){
        $request = Request::instance();
        $request->param();//获取所有参数，最全
        return $request->post();//获取post参数
    }

    //新建图片
    public function createImg(){
        $post = $this->getParams();
        $id =  $post['id'];
        $url =  $post['url'];
        $data = ['id' => $id, 'url' => $url];
        Db::table('image') -> insert($data);
        return json(new SuccessMessage(),201);
    }

    //新建植物
    public function createPlant(){
        $post = $this->getParams();
        $data = ['id' => $post['id'],
            'name' => $post['name'],
            'price' => $post['price'],
            'stock' => $post['stock'],
            'category_id' => $post['category'],
            'main_img_url' => $post['url'],
            'img_id' => $post['img_id'],
            'star' => $post['star'],
            'flower_language' => $post['flower_language'] ];
        Db::table('product') -> insert($data);
        return json(new SuccessMessage(),201);
    }

    //新建植物详细信息
    public function createDetail(){
        $post = $this->getParams();
        $id =  $post['id'];
        $img_id =  $post['img_id'];
        $product_id =  $post['product_id'];
        $data = ['id' => $id, 'img_id' => $img_id, 'product_id'=>$product_id];
        Db::table('product_image') -> insert($data);
        return json(new SuccessMessage(),201);
    }

    //新建植物病虫害信息
    public function createPest(){
        $post = $this->getParams();
        $id =  $post['id'];
        $name =  $post['name'];
        $detail =  $post['detail'];
        $product_id = $post['product_id'];
        $data = ['id' => $id, 'name' => $name, 'detail'=>$detail, 'product_id'=>$product_id];
        Db::table('product_pest') -> insert($data);
        return json(new SuccessMessage(),201);
    }

    //新建植物属性信息
    public function createProperty(){
        $post = $this->getParams();
        $id =  $post['id'];
        $name =  $post['name'];
        $detail =  $post['detail'];
        $product_id = $post['product_id'];
        $data = ['id' => $id, 'name' => $name, 'detail'=>$detail, 'product_id'=>$product_id];
        Db::table('product_property') -> insert($data);
        return json(new SuccessMessage(),201);
    }

    //新建植物价值
    public function createWorth(){
        $post = $this->getParams();
        $id =  $post['id'];
        $name =  $post['name'];
        $detail =  $post['detail'];
        $product_id = $post['product_id'];
        $data = ['id' => $id, 'name' => $name, 'detail'=>$detail, 'product_id'=>$product_id];
        Db::table('product_worth') -> insert($data);
        return json(new SuccessMessage(),201);
    }
}