<?php


namespace app\api\model;


class ProductBreeding extends BaseModel
{
    protected $hidden = ['delete_time','update_time','id'];
}