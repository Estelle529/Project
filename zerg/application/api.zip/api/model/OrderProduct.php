<?php


namespace app\api\model;


class OrderProduct extends BaseModel
{

}